﻿public static class ToastManager {
    public static void DisplayToast(string message) {
    }
}