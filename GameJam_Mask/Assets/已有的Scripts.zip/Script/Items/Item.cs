﻿using Scenes.Interaction;

namespace Items {
    public class Item {
        public void OnInteract(IInteractable interactable) {
        }
    }
}