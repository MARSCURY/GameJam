﻿using System.Collections.Generic;
using Items;

namespace Ideas {
    //念头
    public class IdeaManager {
        public static Dictionary<string, Idea> Ideas { get; } = new();

        public record Idea {
            public string Title { get; }
            public string Message { get; }
            public string Texture { get; }

            public Idea() {
                IdeaWrapper _ = new(this);
            }
        }
    }
}