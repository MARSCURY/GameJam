﻿using UnityEngine;

namespace Scenes.Interaction {
    //交互检测主脚本
    //直接挂载到主摄像机（Main Camera），确保主摄像机的Tag 为 MainCamera（否则Camera.main会返回null，射线创建失败）
    public class InteractDetector : MonoBehaviour {
        [Header("检测配置")] [Tooltip("射线最大检测距离，根据3D场景大小调整（如大型场景设500f）")]
        public float rayMaxDistance = 100f;

        [Tooltip("是否打印交互日志（调试用，发布可关闭）")] public bool showInteractLog = true;

        private void Update() {
            // 检测所有鼠标按键点击（0=左键，1=右键，2=中键）
            for (int mouseButton = 0; mouseButton < 3; mouseButton++) {
                if (Input.GetMouseButtonDown(mouseButton)) {
                    this.Detect3DInteractObject(mouseButton);
                    break; // 单次仅响应一个按键，避免多键同时触发
                }
            }
        }

        /// <summary>
        /// 3D射线检测核心方法，携带鼠标按键信息
        /// </summary>
        /// <param name="mouseButton">点击的鼠标按键（0=左键，1=右键，2=中键）</param>
        private void Detect3DInteractObject(int mouseButton) {
            // 1. 创建从主相机到鼠标屏幕位置的3D射线（Camera.main需主相机Tag为MainCamera）
            Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);

            // 2. 发射3D射线，检测碰撞体
            if (Physics.Raycast(ray, out RaycastHit hitInfo, this.rayMaxDistance)) {
                // 3. 获取被命中物体的Interactable组件（自动识别自身/子类挂载的脚本）
                IInteractable interactable = hitInfo.collider.GetComponent<IInteractable>();

                // 4. 存在Interactable组件（含子类）则触发交互，传入鼠标按键
                if (interactable != null) {
                    interactable.OnInteract(mouseButton);

                    // 可选日志：打印交互信息（物体名+点击按键）
                    if (this.showInteractLog) {
                        string buttonName = mouseButton switch {
                            0 => "左键",
                            1 => "右键",
                            2 => "中键",
                            _ => mouseButton.ToString()
                        };
                        Debug.Log($"[3D交互] 物体「{hitInfo.collider.gameObject.name}」被{buttonName}点击触发交互", hitInfo.collider.gameObject);
                    }
                }
            }
        }

        // 场景视图绘制3D检测射线（调试用，绿色射线直观看到检测范围）
        private void OnDrawGizmos() {
            Gizmos.color = Color.green;
            Ray ray = Camera.main?.ScreenPointToRay(Input.mousePosition) ?? new Ray();
            Gizmos.DrawLine(ray.origin, ray.origin + ray.direction * this.rayMaxDistance);
        }
    }
}