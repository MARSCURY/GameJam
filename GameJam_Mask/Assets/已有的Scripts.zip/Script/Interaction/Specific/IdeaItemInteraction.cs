﻿using Ideas;
using Items;
using UnityEngine;

namespace Scenes.Interaction.Specific {
    public class IdeaItemInteraction : MonoBehaviour, IInteractable {
        public string IdeaId { get; }

        public void OnInteract(int mouseButton) {
            IdeaManager.Idea idea = IdeaManager.Ideas[this.IdeaId];
            if (idea == null) Debug.LogError($"Unknown id {this.IdeaId} for idea", this);
            else if (PlayDataManager.Inventory.TryInsertItem(PlayDataManager.ViewingItem = IdeaWrapper.ByIdea[idea]))
                ToastManager.DisplayToast(idea.Message);
        }
    }
}