﻿namespace Masks {
    public interface IMask {
        MaskType GetMask();
    }
}