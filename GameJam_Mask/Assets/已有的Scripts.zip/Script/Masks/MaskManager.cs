﻿namespace Masks {
    public class MaskManager {
    }
}